#ifndef __PWM_H
#define __PWM_H
#include "stm32f4xx.h"

void TIM2_PWM_Init(u32 arr,u32 psc);
void TIM4_PWM_Init(u32 arr,u32 psc);
void SetPWMDutyCycle(uint8_t channel, uint16_t dutyCycle);
void ActivatePWMPort(uint8_t channel);

void fuwei(void);


#endif
