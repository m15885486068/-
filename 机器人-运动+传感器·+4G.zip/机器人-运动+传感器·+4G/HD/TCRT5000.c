#include "stm32f4xx.h"                  // Device header
#include "TCRT5000.h"
#include "Beep.h"
#include "motor.h"
#include "delay.h"
#include "json.h" 

void TCRT5000_Init(void)
{
	
	
	
	 GPIO_InitTypeDef GPIO_InitStructure;
    EXTI_InitTypeDef EXTI_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14 | GPIO_Pin_13 | GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource14); 
	  SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource13); 
	  SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource11); 

    EXTI_InitStructure.EXTI_Line = EXTI_Line14|EXTI_Line13|EXTI_Line11;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising; //��ͷ�����ش���
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn; 
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 4;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 4;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
	
}

void EXTI15_10_IRQHandler(void)
{
    if(EXTI_GetITStatus(EXTI_Line14) != RESET) 
    {
        	car_fdf();
	        Beep_jb();

        EXTI_ClearITPendingBit(EXTI_Line14); // ���EXTI���жϵȴ�λ
    }
		
		
		 if(EXTI_GetITStatus(EXTI_Line11) != RESET) 
    {
       car_fdb();
	     Beep_jb();

        EXTI_ClearITPendingBit(EXTI_Line11); 
    }
		
		
		 if(EXTI_GetITStatus(EXTI_Line13) != RESET) 
    {
        car_fdb();
	      Beep_jb();

        EXTI_ClearITPendingBit(EXTI_Line13); 
    }
		
}



	





	
	
	



