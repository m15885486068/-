#include "stm32f4xx.h"  
#include "json.h" 
#include "DHT11.h"
#include "MQ2.h"
#include "Beep.h"
#include "GPS.h" 
#include "string.h"

double Smog_yu = 30;//CO����ֵ
double latitude = 0.0;
double longitude = 0.0; 

  


//json���ݴ��
void SendData_Json(void) {
    float Smog_ppm = Smog_GetPPM();
    float temp_value = DHT11_Data.temp_int + DHT11_Data.temp_deci / 100.0;
    float humi_value = DHT11_Data.humi_int * 0.6 + DHT11_Data.humi_deci / 100.0;
   
	
   if(DHT11_ReadData(&DHT11_Data) == 0)
		{
        printf("{\"params\":{\"temp\":%.1f,\"humi\":%.1f,\"smog\":%.2f,\"yu\":%.2f,\"Lat\":%.5f,\"Lng\":%.5f}}",
               temp_value, humi_value, Smog_ppm, Smog_yu, latitude, longitude);
			delay_ms(2000);
    }
    
    
}