#include "stm32f4xx.h"                  // Device header
#include "Beep.h"   
#include "delay.h"  
#include "stdio.h" 
#include "json.h" 

void Beep_Init(void)
{    	 
  GPIO_InitTypeDef  GPIO_InitStructure;

  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);//ʹ��GPIOʱ��

  //GPIOA9,A10��ʼ������
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//��ͨ���ģʽ
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
  GPIO_InitStructure.GPIO_Speed = GPIO_High_Speed;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
  GPIO_Init(GPIOB, &GPIO_InitStructure);//��ʼ��
	
	PBout(12)=0;
   
  
}


	int o;
void Beep_jb(void)
{

	for( o=0;o<3;o++)
	{
		PBout(12)=1;
	delay_ms(100);
  PBout(12)=0;
	delay_ms(100);
	}
 
	
}
