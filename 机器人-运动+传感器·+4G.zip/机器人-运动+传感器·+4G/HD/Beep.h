#ifndef __BEEP_H
#define __BEEP_H
#include "sys.h"


#define Beep PBout(12)	// 

void Beep_Init(void);
void Beep_jb(void);
 				    
#endif
