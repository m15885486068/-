#ifndef __LIGHT_H
#define __LIGHT_H
#include "sys.h"



//LED�˿ڶ���
#define fire0 PCout(11)	// DS0
#define Light1 PCout(12)	// DS1	 

void Light_Init(void);			    
#endif
