#ifndef __TCRT5000_H
#define __TCRT5000_H


#include "stm32f4xx.h"


void TCRT5000_Init(void);
void EXTI15_10_IRQHandler(void);


#endif
