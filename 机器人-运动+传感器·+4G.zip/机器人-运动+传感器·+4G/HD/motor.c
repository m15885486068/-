#include "stm32f4xx.h"                  // Device header
#include  "delay.h"
#include  "motor.h"
#include "TCRT5000.h"
#include "json.h" 

//��ʼ���߼����ƿ� GPIOD 0  1 3 4   

void motor_Init (void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;

  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);//ʹ��GPIOʱ��

  //��ʼ��
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_2| GPIO_Pin_4| GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//��ͨ���ģʽ
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
  GPIO_Init(GPIOD, &GPIO_InitStructure);//��ʼ��


}


	
		void car_go_high(void)  //   ֱ��
	{
	  GPIO_ResetBits(GPIOD,GPIO_Pin_0 | GPIO_Pin_4);
		GPIO_SetBits(GPIOD,GPIO_Pin_2 | GPIO_Pin_6); //����߼�Ϊ1010   
		
	}
			
	void car_back(void) //����
	
{
	  GPIO_SetBits(GPIOD,GPIO_Pin_0 | GPIO_Pin_4);  
		GPIO_ResetBits(GPIOD,GPIO_Pin_2 | GPIO_Pin_6);
	
}

	void car_stop(void)  //ֹͣ
	{

			GPIO_ResetBits(GPIOD,GPIO_Pin_2 | GPIO_Pin_4|GPIO_Pin_0 | GPIO_Pin_6);
	
	}
	
	void car_left(void)  //��ת
	{

		GPIO_SetBits(GPIOD,GPIO_Pin_0 | GPIO_Pin_6); 
		GPIO_ResetBits(GPIOD,GPIO_Pin_2 | GPIO_Pin_4);

	}
	
	void car_right(void)  //��ת
	{
		
		GPIO_SetBits(GPIOD,GPIO_Pin_2 | GPIO_Pin_4);  
		GPIO_ResetBits(GPIOD,GPIO_Pin_0 | GPIO_Pin_6);

	}

	void car_fdf(void){     //����
	
	car_go_high();
		delay_ms(500);
	  car_stop();  
	}

	void car_fdb(void){     //����
	
	  car_back();
		delay_ms(500);
	  car_stop();  
}	