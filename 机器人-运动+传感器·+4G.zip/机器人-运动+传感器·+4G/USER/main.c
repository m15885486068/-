#include "stm32f4xx.h"
#include "usart.h"
#include "delay.h"
#include "Serial.h"
#include "LED.h" 
#include "motor.h"
#include "Beep.h" 
#include "TCRT5000.h"
#include "DHT11.h"
#include "PWM.h"
#include "MQ2.h"
#include "Light.h" 
#include "json.h" 
#include "GPS.h"



int main(void)
{  
	
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8); 
	delay_init(168);  
  Serial_Init();
	TCRT5000_Init();
	LED_Init();
  motor_Init ();
  LED0 = !LED0;
	Beep_Init();
	dht11_init();
	MQ2_Init();
	TIM4_PWM_Init(3000-1,84-1);  // PWMƵ�ʣ�20ms����  84MHz Clock divided by 84 = 1MHz
  TIM2_PWM_Init(3000-1,84-1); 
  Light_Init();	
  SendData_Json();
	USART3_init();
	
	
	
		while(1)  {
	SendData_Json(); 			//�����ϱ�
  GPS_data();
		
		}
}
